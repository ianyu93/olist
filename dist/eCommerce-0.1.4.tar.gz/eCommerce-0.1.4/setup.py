# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eCommerce']

package_data = \
{'': ['*']}

install_requires = \
['pystan>=3.0.0,<4.0.0']

setup_kwargs = {
    'name': 'ecommerce',
    'version': '0.1.4',
    'description': "Custom-built package for statistical analysis and predictive modeling on Olist's Kaggle Data",
    'long_description': None,
    'author': 'Ian Yu',
    'author_email': 'ian.yu@arc.com.co',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
